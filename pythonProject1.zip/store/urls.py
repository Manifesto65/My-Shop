from django.urls import path
from store.views.home import Index
from store.views.signup import signup
from .views import Login
from .views.login import logout
from store.views.cart import Cart
from store.views.checkout import Checkout
from .views.order import OrderView



urlpatterns = [
    path('', Index.as_view(), name='homepage'),
    # using name to redirect to the homepage.This is done because if the domain is change there will be difficulty in changing the address
    path('signup/', signup, name='signup'),
    path('login', Login.as_view(), name='login'),
    path('logout', logout, name='logout'),
    path('cart', Cart.as_view(), name='cart'),
    path('checkout', Checkout.as_view(), name='checkout'),
    path('orders', OrderView.as_view(), name='orders'),

]
